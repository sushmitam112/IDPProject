**Project Title: Analysis of Trends and Factors of College Enrollment and Admissions for 4-year Universities in the United States**
Sushmita Musunuri and Lalitha Chandolu, Period 3

> Sometimes Replit isn't able to run the whole project and states that the program
> was suddenly killed, so you might need
> to download this whole project. Everything should work as it is organized here.
>
> 
> The libraries that you would need installed are pandas, geopandas, pyogrio, numpy,
> seaborn, sklearn, and matplotlib.
> Download the files locally, and just run python main.py and all of the methods should be called.
> Link to Datasets: https://drive.google.com/drive/folders/1MaWHBPTd-dzlL0uz887Tk_gjzWWTmKty?usp=share_link
